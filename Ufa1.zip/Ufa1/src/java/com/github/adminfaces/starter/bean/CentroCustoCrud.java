package com.github.adminfaces.starter.bean;

import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;

import br.upf.dados.beans.CentroCusto;
import br.upf.dados.beans.Cliente;
import br.upf.dados.beans.Filial;
import java.io.IOException;
import java.io.Serializable;
import javax.persistence.Query;


@ManagedBean
@SessionScoped
public class CentroCustoCrud {
//centros de custo cadastradso para apontamentos de atividades

    private List<CentroCusto> lista;
    private CentroCusto objeto = new CentroCusto();
    private Cliente obj = new Cliente();

    public List<CentroCusto> getLista() {
        return lista;
    }

    public void setLista(List<CentroCusto> lista) {
        this.lista = lista;
    }

    public CentroCusto getObjeto() {
        return objeto;
    }

    public void setObjeto(CentroCusto objeto) {
        this.objeto = objeto;
    }

    public Cliente getObj() {
        return obj;
    }

    public void setObj(Cliente obj) {
        this.obj = obj;
    }

}
